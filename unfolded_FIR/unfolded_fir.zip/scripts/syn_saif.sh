#!/bin/bash
cd ../syn
source /software/scripts/init_synopsys_64.18
vcd2saif -input ../vcd/UNFOLDED_FIR_syn.vcd -output ../saif/UNFOLDED_FIR_syn.saif
rm -r work
mkdir work
dc_shell-xg-t -f ../scripts/syn_saif.tcl

