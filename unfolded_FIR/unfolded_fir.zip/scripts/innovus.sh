#!/bin/bash
cd ../innovus
source /software/scripts/init_innovus17.11
innovus
