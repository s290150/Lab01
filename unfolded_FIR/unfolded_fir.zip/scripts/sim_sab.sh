#!/bin/bash
cd ../sim_sab
source /software/scripts/init_msim6.2g
vlib work
make #makefile doesnt allow to change directory, so it must be in the sim dir
vsim -L /software/dk/nangate45/verilog/msim6.2g -sdftyp /tb_fir/UUT=../netlist/unfolded_FIR.sdf work.tb_fir -c -do ../scripts/sim_sab.do
