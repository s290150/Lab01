#!/bin/bash
cd ../sim
source /software/scripts/init_msim6.2g
vlib work
vcom -93 -work ./work ../src/types_pkg.vhd
vcom -93 -work ./work ../src/*.vhd
vcom -93 -work ./work ../tb/*.vhd
vlog -work ./work ../tb/*.v
vsim work.tb_fir -c -do ../scripts/sim.do

