fpm = fopen('resultsm_7bit.txt', 'r');
fpc = fopen('resultsc_7bit.txt', 'r');
ym = fscanf(fpm,'%d\n');
yc = fscanf(fpc,'%d\n');
fclose('all');
figure('name', 'M filter results')
thd(ym);
%%
figure('name', 'C filter results')
thd(yc);