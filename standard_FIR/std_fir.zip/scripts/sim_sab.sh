#!/bin/bash
cd ../sim_sab
source /software/scripts/init_msim6.2g
vlib work
vcom -93 -work ./work ../tb/*.vhd
vlog -work ./work ../netlist/FIR.v
vlog -work ./work ../tb/tb_fir.v
vsim -L /software/dk/nangate45/verilog/msim6.2g -sdftyp /tb_fir/UUT=../netlist/FIR.sdf work.tb_fir -c -do ../scripts/sim_sab.do
