#!/bin/bash
cd ../syn
source /software/scripts/init_synopsys_64.18
rm -r work
mkdir work
dc_shell-xg-t -f ../scripts/syn.tcl

