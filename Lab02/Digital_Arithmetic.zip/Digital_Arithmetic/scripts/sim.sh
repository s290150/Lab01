#!/bin/bash
cd ../sim
rm -r work
source /software/scripts/init_msim6.2g
vlib work
vcom -93 -work ./work ../src_MBE/REG.vhd
vcom -93 -work ./work ../src_MBE/unpackfp_unpackfp.vhd
vcom -93 -work ./work ../src_MBE/fpround_fpround.vhd
vcom -93 -work ./work ../src_MBE/fpnormalize_fpnormalize.vhd
vcom -93 -work ./work ../src_MBE/packfp_packfp.vhd
vcom -93 -work ./work ../src_MBE/fpmul_stage1_struct.vhd
vcom -93 -work ./work ../src_MBE/fpmul_stage1_struct.vhd
vcom -93 -work ./work ../src_MBE/fpmul_stage2_struct.vhd
vcom -93 -work ./work ../src_MBE/fpmul_stage3_struct.vhd
vcom -93 -work ./work ../src_MBE/fpmul_stage4_struct.vhd
vcom -93 -work ./work ../src_MBE/fpmul_pipeline.vhd
vcom -93 -work ./work ../tb/clk_gen.vhd
vcom -93 -work ./work ../tb/data_maker.vhd
vcom -93 -work ./work ../tb/data_sink.vhd
vlog -work ./work ../tb/tb_mul.v
vsim work.tb_mul -do ../scripts/sim.do
